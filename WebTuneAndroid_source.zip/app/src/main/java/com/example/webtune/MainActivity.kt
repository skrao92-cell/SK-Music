package com.example.webtune

import android.app.DownloadManager
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.core.content.ContextCompat
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

data class Track(val title: String, val creator: String, val url: String, val id: String)

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var searchBox: EditText
    private lateinit var results: LinearLayout
    private lateinit var downloads: LinearLayout
    private lateinit var status: TextView
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var downloadReceiver: BroadcastReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        connectPlayer()
        refreshDownloads()
        registerDownloadReceiver()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 24)
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "WebTune"
            textSize = 28f
            setTextColor(0xFF245B9E.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Find freely downloadable music and save it for offline listening."
            textSize = 14f
        })

        searchBox = EditText(this).apply { hint = "Search artist, song or keyword" }
        root.addView(searchBox, ViewGroup.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "Search free music"
            setOnClickListener { searchMusic(searchBox.text.toString().trim()) }
        })
        status = TextView(this).apply { text = "Search results from Internet Archive audio collections." }
        root.addView(status)
        root.addView(sectionTitle("Search results"))
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(results)
        root.addView(sectionTitle("Downloaded — available offline"))
        downloads = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(downloads)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 19f
        setPadding(0, 22, 0, 8)
    }

    private fun searchMusic(query: String) {
        if (query.isBlank()) { status.text = "Enter a song, artist or keyword."; return }
        status.text = "Searching…"
        results.removeAllViews()
        scope.launch {
            try {
                val tracks = withContext(Dispatchers.IO) {
                    val q = URLEncoder.encode("(${query}) AND mediatype:audio", "UTF-8")
                    val url = java.net.URL("https://archive.org/advancedsearch.php?q=$q&fl[]=identifier,title,creator&rows=20&page=1&output=json")
                    val json = JSONObject(url.readText())
                    val docs = json.getJSONObject("response").getJSONArray("docs")
                    val found = mutableListOf<Track>()
                    for (i in 0 until docs.length()) {
                        val doc = docs.getJSONObject(i)
                        val id = doc.optString("identifier")
                        if (id.isBlank()) continue
                        try {
                            val metaUrl = java.net.URL("https://archive.org/metadata/$id")
                            val meta = JSONObject(metaUrl.readText())
                            val files = meta.optJSONArray("files") ?: continue
                            for (j in 0 until files.length()) {
                                val f = files.getJSONObject(j)
                                val name = f.optString("name")
                                val format = f.optString("format").lowercase()
                                if (name.lowercase().endsWith(".mp3") || name.lowercase().endsWith(".ogg") ||
                                    name.lowercase().endsWith(".m4a") || format.contains("mp3")) {
                                    val encodedName = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                                    val audioUrl = "https://archive.org/download/$id/$encodedName"
                                    found.add(Track(doc.optString("title", id), doc.optString("creator", "Unknown artist"), audioUrl, id))
                                    break
                                }
                            }
                        } catch (_: Exception) { }
                    }
                    found
                }
                results.removeAllViews()
                if (tracks.isEmpty()) status.text = "No downloadable audio files found. Try another search."
                else status.text = "Found ${tracks.size} downloadable audio items. Check each item's licence/rights before use."
                tracks.forEach { addTrackRow(it) }
            } catch (e: Exception) {
                status.text = "Search failed: ${e.message ?: "Check your internet connection."}"
            }
        }
    }

    private fun addTrackRow(track: Track) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 10, 0, 10)
        }
        row.addView(TextView(this).apply {
            text = track.title
            textSize = 16f
        })
        row.addView(TextView(this).apply {
            text = track.creator
            textSize = 12f
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "Play"
            setOnClickListener { playUrl(track.url, track.title) }
        })
        actions.addView(Button(this).apply {
            text = "Download"
            setOnClickListener { downloadTrack(track) }
        })
        row.addView(actions)
        results.addView(row)
        results.addView(View(this).apply { setBackgroundColor(0xFFE3E7EC.toInt()) },
            ViewGroup.LayoutParams(-1, 1))
    }

    private fun downloadTrack(track: Track) {
        try {
            val safeName = (track.title.replace(Regex("[^A-Za-z0-9._ -]"), "").take(60).ifBlank { "audio" }) + ".mp3"
            val request = DownloadManager.Request(Uri.parse(track.url))
                .setTitle(track.title)
                .setDescription("Downloading for offline listening")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_MUSIC, safeName)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "Download started: ${track.title}"
        } catch (e: Exception) {
            status.text = "Could not start download: ${e.message}"
        }
    }

    private fun registerDownloadReceiver() {
        downloadReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                refreshDownloads()
            }
        }
        ContextCompat.registerReceiver(
            this, downloadReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun refreshDownloads() {
        downloads.removeAllViews()
        val dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC)
        val files = dir?.listFiles()?.filter { it.isFile && it.length() > 0 } ?: emptyList()
        if (files.isEmpty()) {
            downloads.addView(TextView(this).apply { text = "No downloaded tracks yet." })
            return
        }
        files.forEach { file ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = file.name; textSize = 14f }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Play"
                setOnClickListener { playUrl(Uri.fromFile(file).toString(), file.name) }
            })
            downloads.addView(row)
        }
    }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
    }

    private fun playUrl(url: String, title: String) {
        val future = controllerFuture
        if (future == null) { status.text = "Player is starting. Try again."; return }
        future.addListener({
            try {
                val player = future.get()
                player.setMediaItem(MediaItem.Builder().setUri(url).setMediaMetadata(
                    androidx.media3.common.MediaMetadata.Builder().setTitle(title).build()
                ).build())
                player.prepare()
                player.play()
                status.text = "Playing: $title"
            } catch (e: Exception) {
                status.text = "Playback failed: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        downloadReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        controllerFuture?.let { MediaController.releaseFuture(it) }
        scope.cancel()
        super.onDestroy()
    }
}
