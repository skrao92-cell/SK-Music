# WebTune Android starter

This is a native Android Studio project for a basic web-search + legal-download + offline-player prototype.

## What it does
- Searches Internet Archive audio records.
- Reads item metadata and looks for downloadable MP3/OGG/M4A files.
- Lets the user stream a result or download it using Android DownloadManager.
- Lists downloaded audio in the app and plays it through Media3.
- Uses a MediaSessionService so playback can continue in the background.

## Important rights and source limits
"Anywhere on the web" does not mean every website permits downloading. This prototype searches Internet Archive only and exposes files that the archive makes directly downloadable. Check the rights/licence shown on each item before downloading, sharing or using it. It does not bypass DRM, paywalls, access controls, or site restrictions. It is not a YouTube downloader.

## Build an APK
1. Install Android Studio (latest stable) on Windows/macOS/Linux.
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Connect the Pixel 7 with USB debugging enabled, or use an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is a starter prototype, not a polished Play Store release.
- Network search requires internet; downloaded tracks play offline.
- Downloads are stored in the app-specific Music folder and are removed if the app is uninstalled.
- Search results and downloadable file availability depend on Internet Archive metadata and may vary.
- A production version should add licence display, duplicate detection, download progress/cancel, robust file naming, error handling, and user testing.
